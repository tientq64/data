var App = m.comp({
   oninit: function () {
      this.atoms = [];
      this.groups = [];

      // Bán kính hạt:
      this.radius = 3;

      this.gMaps = [];
   },
   oncreate: function () {
      this.updateSize();

      // Số lượng mỗi hạt mỗi nhóm mặc định là 200:
      this.addGroup(200, "#e11d48");
      this.addGroup(200, "#d97706");
      this.addGroup(200, "#16a34a");
      this.addGroup(200, "#2563eb");
      this.addGroup(200, "#475569");
      this.addGroup(200, "#7c3aed");
      this.addGroup(200, "#0891b2");
      this.addGroup(200, "#c026d3");
      this.addGroup(200, "#fff");
      this.render();
      window.addEventListener("resize", this.updateSize);
      m.redraw();
   },
   render: function () {
      var i$, ref$, len$, group, j$, ref1$, len1$, group2, atom, x, y, diameter;
      for (i$ = 0, len$ = (ref$ = this.groups).length; i$ < len$; ++i$) {
         group = ref$[i$];
         for (j$ = 0, len1$ = (ref1$ = this.groups).length; j$ < len1$; ++j$) {
            group2 = ref1$[j$];
            this.rule(group.atoms, group2.atoms, this.gMaps[group.color][group2.color]);
         }
      }
      this.g.clearRect(0, 0, this.width, this.height);
      this.g.fillStyle = "black";
      this.g.fillRect(0, 0, this.width, this.height);
      for (i$ = 0, len$ = (ref$ = this.atoms).length; i$ < len$; ++i$) {
         atom = ref$[i$];
         x = atom.x - this.radius;
         y = atom.y - this.radius;
         diameter = this.radius * 2;
         this.g.fillStyle = atom.color;
         this.g.fillRect(x, y, diameter, diameter);
      }
      requestAnimationFrame(this.render);
   },
   updateSize: function () {
      this.width = this.viewerVnode.dom.offsetWidth;
      this.height = this.viewerVnode.dom.offsetHeight;
      this.canvasVnode.dom.width = this.width;
      this.canvasVnode.dom.height = this.height;
      this.g = this.canvasVnode.dom.getContext("2d");
   },
   addGroup: function (num, color) {
      var group, i$, i, atom, ref$, len$, j$, ref1$, len1$, group2, ref2$, key$, ref3$, key1$;
      group = {
         color: color,
         atoms: []
      };
      for (i$ = 0; i$ < num; ++i$) {
         i = i$;
         atom = {
            x: this.random(this.width * 0.25, this.width * 0.75),
            y: this.random(this.height * 0.25, this.height * 0.75),
            vx: 0,
            vy: 0,
            color: color
         };
         group.atoms.push(atom);
         this.atoms.push(atom);
      }
      this.groups.push(group);
      for (i$ = 0, len$ = (ref$ = this.groups).length; i$ < len$; ++i$) {
         group = ref$[i$];
         for (j$ = 0, len1$ = (ref1$ = this.groups).length; j$ < len1$; ++j$) {
            group2 = ref1$[j$];
            (ref2$ = (ref3$ = this.gMaps)[key1$ = group.color] || (ref3$[key1$] = {}))[key$ = group2.color] == null && (ref2$[key$] = 0);
         }
      }
      m.redraw();
   },
   rule: function (atoms, atoms2, g) {
      var i$, len$, atom, fx, fy, j$, len1$, atom2, dx, dy, d, f;
      for (i$ = 0, len$ = atoms.length; i$ < len$; ++i$) {
         atom = atoms[i$];
         fx = 0;
         fy = 0;
         for (j$ = 0, len1$ = atoms2.length; j$ < len1$; ++j$) {
            atom2 = atoms2[j$];
            if (atom === atom2) {
               continue;
            }
            dx = atom.x - atom2.x;
            dy = atom.y - atom2.y;
            d = Math.sqrt(dx * dx + dy * dy);

            // Khoảng cách tương tác cố định:
            let maxDistance = 160;

            // Khoảng cách tương tác ngẫu nhiên:
            // let maxDistance = this.random(80, 160);

            if (d > 0 && d < maxDistance) {
               f = g * 1 / d;
               fx += f * dx;
               fy += f * dy;
            }
         }
         atom.vx = (atom.vx + fx) * 0.5;
         atom.vy = (atom.vy + fy) * 0.5;
         atom.x += atom.vx;
         atom.y += atom.vy;
         if (atom.x < this.radius || atom.x >= this.width - this.radius) {
            atom.x = this.width / 2;
         }
         if (atom.y < this.radius || atom.y >= this.height - this.radius) {
            atom.y = this.height / 2;
         }
      }
   },
   random: function (min, max) {
      max = [1, min, max][arguments.length];
      min = [0, 0, min][arguments.length];
      return min + Math.random() * (max - min + 1);
   },
   getBgColorByG: function (g) {
      if (g > 0) {
         return "rgba(0, 128, 0, " + g + ")";
      } else if (g < 0) {
         return "rgba(255, 0, 0, " + (-g) + ")";
      } else {
         return "#0000";
      }
   },
   onclickG: function (g, groupA, groupB, event) {
      this.gMaps[groupA.color][groupB.color] = Number((g + 0.1).toFixed(2));
   },
   onauxclickG: function (g, groupA, groupB, event) {
      if (event.button = 1) {
         this.gMaps[groupA.color][groupB.color] = 0;
      }
   },
   oncontextmenuG: function (g, groupA, groupB, event) {
      this.gMaps[groupA.color][groupB.color] = Number((g - 0.1).toFixed(2));
   },
   onclickRandomG: function (event) {
      var k, ref$, val, k2, g;
      for (k in ref$ = this.gMaps) {
         val = ref$[k];
         for (k2 in val) {
            g = val[k2];
            val[k2] = Number((this.random(-10, 10) / 10).toFixed(2));
         }
      }
   },
   view: function () {
      return m(".row.h-100",
         m(".col-0.p-3", {
            style: m.style({
               width: 280
            })
         },
            m("p", "Lực tương tác:"),
            m(".grid", {
               style: m.style({
                  gridTemplateColumns: "repeat(" + (this.groups.length + 1) + ", 1fr)",
                  gridAutoRows: 32,
               })
            },
               m(".div", "\xa0"),
               this.groups.map((group => {
                  return m("div", {
                     style: {
                        background: group.color
                     }
                  });
               })),
               this.groups.map((groupA => {
                  return m.fragment(
                     m("div", {
                        style: {
                           background: groupA.color
                        }
                     }),
                     this.groups.map((groupB => {
                        var g;
                        g = this.gMaps[groupB.color][groupA.color];
                        return m("small.flex.center.middle", {
                           style: {
                              background: this.getBgColorByG(g)
                           },
                           onclick: this.onclickG.bind(void 8, g, groupB, groupA),
                           onauxclick: this.onauxclickG.bind(void 8, 0, groupB, groupA),
                           oncontextmenu: this.oncontextmenuG.bind(void 8, g, groupB, groupA)
                        }, g > 0 && "+", (g * 10).toFixed(0));
                     }))
                  );
               }))
            ),
            m("p",
               m("button", {
                  onclick: this.onclickRandomG
               }, "Ngẫu nhiên")
            ),
            m("p",
               m("div", "Chuột trái: +1"),
               m("div", "Chuột phải: -1"),
               m("div", "Chuột giữa: =0")
            ),
            m("p",
               m("div", "Cột dọc là A, cột ngang là B"),
               m("div", "Lực > 0, A đẩy B"),
               m("div", "Lực < 0, A hút B")
            )
         ),
         this.viewerVnode = m(".col", this.canvasVnode = m("canvas"))
      );
   }
});

m.mount(document.body, App);

window.addEventListener("contextmenu", event => {
   event.preventDefault();
});
